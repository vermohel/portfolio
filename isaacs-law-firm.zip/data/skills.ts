export const skills = [
  {
    name: "React / Next.js",
    percentage: 90,
  },
  {
    name: "JavaScript / TypeScript",
    percentage: 85,
  },
  {
    name: "HTML / CSS",
    percentage: 95,
  },
  {
    name: "Tailwind CSS",
    percentage: 90,
  },
  {
    name: "UI/UX Design",
    percentage: 80,
  },
  {
    name: "Animation / Motion",
    percentage: 85,
  },
  {
    name: "Responsive Design",
    percentage: 95,
  },
  {
    name: "Accessibility",
    percentage: 85,
  },
]

